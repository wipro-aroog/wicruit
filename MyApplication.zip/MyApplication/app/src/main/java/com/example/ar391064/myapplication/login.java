package com.example.ar391064.myapplication;

import android.os.Bundle;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by AR391064 on 04/10/2017.
 */

public class login {
    protected void onCreate(Bundle savedInstanceState) {
        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.login1);


}



}
